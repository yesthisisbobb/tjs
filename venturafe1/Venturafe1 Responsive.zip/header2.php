<div class="container2" id="hidelater">
<img src="img/bg/koh5.jpg" alt="Cloudy Sky" >
<div class="text-block">
<h2 class="animated bounceIn slow" id="hidelater di700">PREMIUM QUALITY</h2>
<p id="hidelater">A High Standard Quality of Tile & Sanitary</p>
<a href="#produkoke" class="btn btn-info" role="button" id="hidelater">Our Products</a>
</div>
</div>
<br><br>
<div class="container">
<div class="row">
  <div class="col-lg-8">

    <div class="row">
      <div class="col-lg-6 pr-0" style="margin-bottom: 15px;">
        <a href="#"><img src="img/tre.jpg" alt="Image" id="floattengah"></a>
      </div>

      <div class="col-lg-6 pr-0" style="margin-bottom: 15px;">
        <a href="#"><img src="img/banner/9.jpg" alt="Image" id="floattengah"></a>
      </div>

      <div class="w-100"></div>

      <div class="col-lg-12 pr-0" id="hidelater">
        <a href="#"><img src="img/fi.jpg" alt="Image"></a>
      </div>
    </div>

  </div>

  <div class="col-lg-4">
    <a href="#"><img src="img/10.jpg" height="550"alt="Image" id="hidelater"></a>
  </div>
</div>
</div>
